package ERP.Garment.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.Remote;

public class Stock extends JFrame
{
    Stock()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/stock.png"));
        Image i2=i1.getImage().getScaledInstance(1120,630, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(0,0,1120,630);
        add(img);

        JLabel heading=new JLabel("Stock Details");
        heading.setBounds(400,120,400,40);
        heading.setFont(new Font("Relaway",Font.BOLD,40));
        heading.setForeground(Color.black);
        img.add(heading);

        JButton view=new JButton("View Stock");
        view.setBounds(420,220,200,40);
        view.setForeground(Color.black);
        view.setBackground(Color.white);
        img.add(view);
        view.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new View_Stock();
            }
        });

        JButton add=new JButton("Add Stock");
        add.setBounds(420,280,200,40);
        add.setForeground(Color.black);
        add.setBackground(Color.white);
        img.add(add);
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Add_Stock();
            }
        });

        JButton remove=new JButton("Remove Stock");
        remove.setBounds(420,340,200,40);
        remove.setForeground(Color.black);
        remove.setBackground(Color.white);
        img.add(remove);
        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Remove_Stock();
            }
        });


        JButton back=new JButton("Back");
        back.setBounds(420,400,200,40);
        back.setBackground(Color.WHITE);
        back.setForeground(Color.BLACK);
        img.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Main_Class();

            }
        });


        setSize(1120,630);
        setLocationRelativeTo(null);
        setLayout(null);
        setVisible(true);
    }
   public static void main(String args[])
   {
       new Stock();
   }
}
