package ERP.Garment.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
public class Update_Stock extends JFrame
{
    Update_Stock(String pname)
    {

        setLayout(null);
        Container c=getContentPane();
        c.setBackground(new Color(20,227,179));

        JLabel heading=new JLabel("Update Stock Details");
        heading.setBounds(300,50,500,40);
        heading.setFont(new Font("serif",Font.BOLD,30));
        c.add(heading);

        JLabel id=new JLabel("ID:");
        id.setBounds(220,150,150,30);
        id.setFont(new Font("arial",Font.BOLD,20));
        c.add(id);

        JTextField tid=new JTextField();
        tid.setBounds(400,150,150,30);
        tid.setFont(new Font("arial",Font.BOLD,20));
        tid.setBackground(new Color(177,252,197));
        tid.setForeground(Color.red);
        c.add(tid);

        JLabel name=new JLabel("Product Name:");
        name.setBounds(220,200,150,30);
        name.setFont(new Font("arial",Font.BOLD,20));
        c.add(name);

        JTextField tname=new JTextField();
        tname.setBounds(400,200,150,30);
        tname.setFont(new Font("arial",Font.BOLD,20));
        tname.setBackground(new Color(177,252,197));
        tname.setForeground(Color.red);
        c.add(tname);

        JLabel price=new JLabel("Product Price:");
        price.setBounds(220,250,150,30);
        price.setFont(new Font("arial",Font.BOLD,20));
        c.add(price);

        JTextField tprice=new JTextField();
        tprice.setBounds(400,250,150,30);
        tprice.setFont(new Font("arial",Font.BOLD,20));
        tprice.setBackground(new Color(177,252,197));
        tprice.setForeground(Color.red);
        c.add(tprice);

        JLabel qty=new JLabel("Product Quantity:");
        qty.setBounds(220,300,150,30);
        qty.setFont(new Font("arial",Font.BOLD,20));
        c.add(qty);

        JTextField tqty=new JTextField();
        tqty.setBounds(400,300,150,30);
        tqty.setFont(new Font("arial",Font.BOLD,20));
        tqty.setBackground(new Color(177,252,197));
        tqty.setForeground(Color.red);
        c.add(tqty);



        try
        {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from stock where p_name='"+pname+"'");

            while(rs.next())
            {
                tid.setText(rs.getString("p_id"));
                tname.setText(rs.getString("p_name"));
                tprice.setText(rs.getString("p_price"));
                tqty.setText(rs.getString("p_qty"));
            }
        }catch(Exception e3)
        {
            e3.printStackTrace();
        }

        JButton save=new JButton("SAVE");
        save.setBounds(250,400,150,30);
        save.setBackground(Color.BLACK);
        save.setForeground(Color.WHITE);
        c.add(save);
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String id=tid.getText();
                String name=tname.getText();
                String price=tprice.getText();
                String qty=tqty.getText();
                String total=""+(Integer.parseInt(price)*Integer.parseInt(qty));

                    try {
                        Class.forName("org.postgresql.Driver");
                        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                        Statement st = con.createStatement();
                        String query = "update stock set p_id='" + id + "',p_name='" + name + "',p_price='" + price + "',p_qty='" + qty + "',total='"+ total +"' where p_name='"+pname+"'";
                        st.executeUpdate(query);

                        JOptionPane.showMessageDialog(null, "Saved Details");
                        setVisible(false);
                        new Stock();
                    } catch (Exception e4) {
                        e4.printStackTrace();
                    }

                }
        });

        JButton back=new JButton("Back");
        back.setBounds(450,400,150,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        c.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new View_Stock();
            }
        });





        setSize(900,700);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String args[])
    {
        new Update_Stock(" ");
    }
}
