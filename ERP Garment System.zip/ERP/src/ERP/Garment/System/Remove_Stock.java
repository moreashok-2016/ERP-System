package ERP.Garment.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.font.ImageGraphicAttribute;
import java.sql.*;
public class Remove_Stock extends JFrame
{
    Remove_Stock()
    {
        setLayout(null);

        JLabel name=new JLabel("Choose Name:");
        name.setBounds(50,50,150,30);
        name.setFont(new Font("Tahoma",Font.BOLD,15));
        add(name);

        Choice ch=new Choice();
        ch.setBounds(200,50,150,30);
        add(ch);

        try
        {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from stock");
            while(rs.next())
            {
                ch.add(rs.getString("p_name"));
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        JLabel id=new JLabel("Id:");
        id.setBounds(50,100,100,30);
        id.setFont(new Font("Tahoma",Font.BOLD,15));
        add(id);

        JLabel tid=new JLabel();
        tid.setBounds(200,100,100,30);
        tid.setFont(new Font("Tahome",Font.ITALIC,15));
        add(tid);

        JLabel pname=new JLabel("Name:");
        pname.setBounds(50,150,100,30);
        pname.setFont(new Font("Tahoma",Font.BOLD,15));
        add(pname);

        JLabel tname=new JLabel();
        tname.setBounds(200,150,100,30);
        tname.setFont(new Font("Tahome",Font.ITALIC,15));
        add(tname);

        try
        {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from stock where p_name='"+ch.getSelectedItem()+"'");

            while(rs.next())
            {
                tid.setText(rs.getString("p_id"));
                tname.setText(rs.getString("p_name"));
            }
        }catch(Exception e2)
        {
            e2.printStackTrace();
        }

        ch.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                try
                {
                    Class.forName("org.postgresql.Driver");
                    Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                    Statement st=con.createStatement();
                    ResultSet rs=st.executeQuery("select * from stock where p_name='"+ch.getSelectedItem()+"'");

                    while(rs.next())
                    {
                        tid.setText(rs.getString("p_id"));
                        tname.setText(rs.getString("p_name"));
                    }
                }catch(Exception e5)
                {
                    e5.printStackTrace();
                }
            }
        });

        JButton delete=new JButton("Delete");
        delete.setBounds(80,300,100,30);
        delete.setBackground(Color.black);
        delete.setForeground(Color.white);
        add(delete);
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    Class.forName("org.postgresql.Driver");
                    Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                    Statement st=con.createStatement();
                    st.executeUpdate("delete from stock where p_name='"+ch.getSelectedItem()+"'");
                    JOptionPane.showMessageDialog(null,"Stock Information Deleted Successfully !");
                    setVisible(false);
                    new Stock();
                }catch(Exception e6)
                {
                    e6.printStackTrace();
                }

            }
        });

        JButton back=new JButton("Back");
        back.setBounds(220,300,100,30);
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Stock();
            }
        });

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/delete.png"));
        Image i2=i1.getImage().getScaledInstance(200,200,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(700,80,200,200);
        add(img);

        ImageIcon i11=new ImageIcon(ClassLoader.getSystemResource("icons/dback.png"));
        Image i22=i11.getImage().getScaledInstance(1120,630,Image.SCALE_DEFAULT);
        ImageIcon i33=new ImageIcon(i22);
        JLabel image=new JLabel(i33);
        image.setBounds(0,0,1120,630);
        add(image);

        setVisible(true);
        setSize(1000,400);
        setLocationRelativeTo(null);
    }
    public static void main(String args[])
    {
        new Remove_Stock();
    }
}
