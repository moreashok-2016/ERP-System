package ERP.Garment.System;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.*;


public class Conn
{
    Conn()
    {
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
        }catch(Exception e)
        {
           e.printStackTrace();
        }
    }

}

