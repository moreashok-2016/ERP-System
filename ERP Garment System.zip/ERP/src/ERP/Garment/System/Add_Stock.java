package ERP.Garment.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
public class Add_Stock extends JFrame
{

    Add_Stock()
    {
        setLayout(null);
        Container c=getContentPane();
        c.setBackground(new Color(20,227,179));

        JLabel heading=new JLabel("Add Stock Details");
        heading.setBounds(300,50,500,40);
        heading.setFont(new Font("serif",Font.BOLD,30));
        c.add(heading);

        JLabel id=new JLabel("Product Id:");
        id.setBounds(250,200,200,30);
        id.setFont(new Font("arial",Font.BOLD,20));
        c.add(id);


        JTextField tid=new JTextField();
        tid.setBounds(430,200,200,30);
        tid.setFont(new Font("arial",Font.BOLD,20));
        tid.setBackground(new Color(177,252,197));
        c.add(tid);

        JLabel name=new JLabel("Product Name:");
        name.setBounds(250,250,200,30);
        name.setFont(new Font("arial",Font.BOLD,20));
        c.add(name);

        JTextField tname=new JTextField();
        tname.setBounds(430,250,200,30);
        tname.setFont(new Font("arial",Font.BOLD,20));
        tname.setBackground(new Color(177,252,197));
        c.add(tname);

        JLabel price=new JLabel("Product Price:");
        price.setBounds(250,300,200,30);
        price.setFont(new Font("arial",Font.BOLD,20));
        c.add(price);

        JTextField tprice=new JTextField();
        tprice.setBounds(430,300,200,30);
        tprice.setFont(new Font("arial",Font.BOLD,20));
        tprice.setBackground(new Color(177,252,197));
        c.add(tprice);

        JLabel qty=new JLabel("Product Quantity:");
        qty.setBounds(250,350,200,30);
        qty.setFont(new Font("arial",Font.BOLD,20));
        c.add(qty);

        JTextField tqty=new JTextField();
        tqty.setBounds(430,350,200,30);
        tqty.setFont(new Font("arial",Font.BOLD,20));
        tqty.setBackground(new Color(177,252,197));
        c.add(tqty);

        JButton add=new JButton("Add Product");
        add.setBounds(250,475,150,30);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        c.add(add);
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String id=tid.getText();
                String name=tname.getText();
                String price=tprice.getText();
                String qty=tqty.getText();
                String total=""+(Integer.parseInt(price)*Integer.parseInt(qty));

                try {
                    Class.forName("org.postgresql.Driver");
                    Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                    Statement st = con.createStatement();
                    st.executeUpdate("insert into stock values('" + id + "','" + name + "','" + price + "','" + qty + "','"+total+"')");

                    JOptionPane.showMessageDialog(null, "Stock Add Successfully");
                    new Stock();
                    setVisible(false);

                } catch (Exception e1) {
                    System.out.println("Exception:" + e1);
                }

            }
        });

        JButton back=new JButton("Back");
        back.setBounds(450,475,150,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        c.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Stock();
            }
        });

        setSize(900,700);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String args[])
    {
        new Add_Stock();
    }

}
