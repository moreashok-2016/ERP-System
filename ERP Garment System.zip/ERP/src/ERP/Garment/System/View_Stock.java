package ERP.Garment.System;
import net.proteanit.sql.DbUtils;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
public class View_Stock extends JFrame
{
    JTable table;
    View_Stock()
    {
        setLayout(null);
        getContentPane().setBackground(new Color(255,131,122));
        JLabel search=new JLabel("Search by Procuct Name:");
        search.setBounds(20,20,150,20);
        add(search);

        Choice ch=new Choice();
        ch.setBounds(180,20,150,20);
        ch.setBackground(Color.white);
        add(ch);
        try
        {
            Class.forName("org.postgresql.Driver");
            Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp","postgres","ashoka");
            Statement st= con.createStatement();
            ResultSet rs=st.executeQuery("select * from stock");
            while(rs.next())
            {
                ch.add(rs.getString("p_name"));
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }

        table=new JTable();
        try
        {
            Class.forName("org.postgresql.Driver");
            Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp","postgres","ashoka");
            Statement st= con.createStatement();
            ResultSet rs= st.executeQuery("select * from stock");

            table.setModel(DbUtils.resultSetToTableModel(rs));
            JScrollPane sp=new JScrollPane(table);
            sp.setBounds(0,100,900,600);
            add(sp);

        }catch (Exception e1)
        {
            e1.printStackTrace();
        }

        JButton search1=new JButton("Search");
        search1.setBounds(20,70,80,20);
        add(search1);
        search1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Class.forName("org.postgresql.Driver");
                    Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                    Statement st=con.createStatement();
                    ResultSet rs=st.executeQuery("select * from stock where p_name='"+ch.getSelectedItem()+"'");
                    table.setModel(DbUtils.resultSetToTableModel(rs));
                }catch (Exception e2)
                {
                    e2.printStackTrace();
                }
            }
        });

        JButton print=new JButton("Print");
        print.setBounds(120,70,80,20);
        add(print);
        print.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                try {

                    table.print();
                }catch (Exception e2)
                {
                    e2.printStackTrace();
                }
            }
        });

        JButton update=new JButton("Update");
        update.setBounds(220,70,80,20);
        add(update);
        update.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Update_Stock(ch.getSelectedItem());
            }
        });

        JButton back=new JButton("Back");
        back.setBounds(320,70,80,20);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Stock();
            }
        });

        JButton exit=new JButton("Exit");
        exit.setBounds(420,70,80,20);
        add(exit);
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Login();
                setVisible(false);
            }
        });




        setSize(900,700);
        setVisible(true);
        setLocationRelativeTo(null);
        setLayout(null);
    }
    public static void main(String args[])
    {
        new View_Stock();
    }
}
