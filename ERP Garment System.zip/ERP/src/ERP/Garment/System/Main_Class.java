package ERP.Garment.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main_Class extends JFrame
{
    Main_Class()
    {
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/home.jpg"));
        Image i2=i1.getImage().getScaledInstance(1120,630, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(0,0,1120,630);
        add(img);

        JLabel heading=new JLabel("Garment ERP System");
        heading.setBounds(360,155,400,40);
        heading.setFont(new Font("Relaway",Font.BOLD,25));
        img.add(heading);

        JButton stock=new JButton("Stock Details");
        stock.setBounds(335,250,150,40);
        stock.setForeground(Color.white);
        stock.setBackground(Color.black);
        img.add(stock);
        stock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new Stock();
            }
        });

        JButton salesman=new JButton("SalesMan Details");
        salesman.setBounds(565,250,150,40);
        salesman.setForeground(Color.white);
        salesman.setBackground(Color.black);
        img.add(salesman);
        salesman.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new SalesMan();
            }
        });

        JButton customer=new JButton("Customer Details");
        customer.setBounds(335,350,150,40);
        customer.setForeground(Color.white);
        customer.setBackground(Color.black);
        img.add(customer);
        customer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new Customer();
            }
        });

        JButton bill=new JButton("Billing Details");
        bill.setBounds(565,350,150,40);
        bill.setForeground(Color.white);
        bill.setBackground(Color.black);
        img.add(bill);
        bill.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new Billing();
            }
        });

        JButton back = new JButton("Back");
        back.setBounds(450, 430, 150, 40);
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        img.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new Login();
            }
        });



        setSize(1120,630);
        setLocationRelativeTo(null);
        setLayout(null);
        setVisible(true);
    }
   public static void main(String args[])
   {
       new Main_Class();
   }
}
