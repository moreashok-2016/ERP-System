package ERP.Garment.System;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Customer extends JFrame
{
    Customer()
    {
        setLayout(null);
        getContentPane().setBackground(new Color(255,131,122));

        JLabel heading=new JLabel("Customer Datails!");
        heading.setBounds(300,10,200,30);
        heading.setFont(new Font("Times with Roman", Font.BOLD, 20));
        add(heading);

        JLabel search=new JLabel("Search by Customer id");
        search.setBounds(20,45,150,20);
        add(search);

        Choice ch=new Choice();
        ch.setBounds(180,45,150,20);
        ch.setBackground(Color.white);
        add(ch);
        try
        {
            Class.forName("org.postgresql.Driver");
            Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp","postgres","ashoka");
            Statement st= con.createStatement();
            ResultSet rs=st.executeQuery("select * from billing");
            while(rs.next())
            {
                ch.add(rs.getString("id"));
            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }

        JTable table=new JTable();
        try
        {
            Class.forName("org.postgresql.Driver");
            Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp","postgres","ashoka");
            Statement st= con.createStatement();
            ResultSet rs= st.executeQuery("select * from billing");
            table.setModel(DbUtils.resultSetToTableModel(rs));
            JScrollPane sp=new JScrollPane(table);
            sp.setBounds(0,110,900,600);
            add(sp);

        }catch (Exception e1)
        {
            e1.printStackTrace();
        }

        JButton search1=new JButton("Search");
        search1.setBounds(20,80,80,20);
        add(search1);
        search1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Class.forName("org.postgresql.Driver");
                    Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                    Statement st=con.createStatement();
                    ResultSet rs=st.executeQuery("select * from billing where id='"+ch.getSelectedItem()+"'");
                    table.setModel(DbUtils.resultSetToTableModel(rs));
                }catch (Exception e2)
                {
                    e2.printStackTrace();
                }

            }
        });

        JButton back=new JButton("Back");
        back.setBounds(320,80,80,20);
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Main_Class();
                setVisible(false);
            }
        });

        setSize(900,700);
        setVisible(true);
        setLocationRelativeTo(null);
        setLayout(null);
    }
    public static void main(String[] args)
    {
        new Customer();
    }
}
