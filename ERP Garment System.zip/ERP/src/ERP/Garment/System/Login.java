package ERP.Garment.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Login extends JFrame
{
    JPasswordField tpass;
    JTextField tname;
    JButton login,back;
    Login()
    {

        JLabel name=new JLabel("User_Name");
        name.setForeground(Color.black);
        name.setBounds(40,40,120,30);
        name.setFont(new Font("serif", Font.BOLD, 15));
        add(name);

        tname=new JTextField();
        tname.setForeground(Color.BLACK);
        tname.setBounds(140,40,150,30);
        add(tname);

        JLabel pass=new JLabel("password");
        pass.setForeground(Color.black);
        pass.setBounds(40,90,120,30);
        pass.setFont(new Font("serif", Font.BOLD, 15));
        add(pass);

        tpass=new JPasswordField();
        tpass.setForeground(Color.BLACK);
        tpass.setBounds(140,90,150,30);
        add(tpass);

        login=new JButton("Login");
        login.setBounds(40,150,100,30);
        login.setForeground(Color.BLACK);
        login.setFont(new Font("serif",Font.BOLD,15));
        add(login);
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
               String name=tname.getText();
               String pass=tpass.getText();

               try
               {
                  Class.forName("org.postgresql.Driver");
                  Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp","postgres","ashoka");
                  Statement st=con.createStatement();
                  ResultSet rs=st.executeQuery("select * from erp where name='"+name+"' and pass='"+pass+"'");
                  if(rs.next())
                  {
                      setVisible(false);
                      new Main_Class();
                  }else
                  {
                      JOptionPane.showMessageDialog(null, "Invalid UserName and Password !");
                  }
               }catch(Exception e1)
                {
                    e1.printStackTrace();
                }
            }
        });


        back=new JButton("Back");
        back.setBounds(160,150,100,30);
        back.setForeground(Color.BLACK);
        back.setFont(new Font("serif",Font.BOLD,15));
        add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e1)
            {
                System.exit(0);
            }
        });

        ImageIcon i11=new ImageIcon(ClassLoader.getSystemResource("icons/L2.jpg"));
        Image i22=i11.getImage().getScaledInstance(250, 210, Image.SCALE_DEFAULT);
        ImageIcon i33=new ImageIcon(i22);
        JLabel img=new JLabel(i33);
        img.setBounds(360,-35,200,300);
        add(img);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/L1.jpg"));
        Image i2=i1.getImage().getScaledInstance(600,300, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(0,0,600,300);
        add(image);

        setSize(600,300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String args[])
    {
        new Login();
    }
}

