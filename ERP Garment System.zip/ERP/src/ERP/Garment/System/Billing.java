package ERP.Garment.System;

import com.toedter.calendar.JDateChooser;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.*;
public class Billing extends JFrame
{
    Billing() {
        JLabel heading=new JLabel("Billing Details");
        heading.setBounds(90,-15,300,100);
        heading.setForeground(Color.black);
        heading.setFont(new Font("Tahoma",Font.BOLD,20));
        add(heading);


        JLabel id=new JLabel("Id:");
        id.setBounds(65,75,100,30);
        id.setFont(new Font("Times New Roman",Font.BOLD,15));
        id.setForeground(Color.black);
        add(id);

        JTextField tid=new JTextField();
        tid.setBounds(175,75,150,25);
        tid.setFont(new Font("Times New Roman",Font.BOLD,15));
        tid.setForeground(Color.black);
        add(tid);

        JLabel name=new JLabel("Name:");
        name.setBounds(65,110,100,30);
        name.setFont(new Font("Times New Roman",Font.BOLD,15));
        name.setForeground(Color.black);
        add(name);

        JTextField tname=new JTextField();
        tname.setBounds(175,110,150,25);
        tname.setFont(new Font("Times New Roman",Font.BOLD,15));
        tname.setForeground(Color.black);
        add(tname);

        JLabel mob=new JLabel("Mob.nO.:");
        mob.setBounds(65,150,100,30);
        mob.setFont(new Font("Times New Roman",Font.BOLD,15));
        mob.setForeground(Color.black);
        add(mob);

        JTextField tmob=new JTextField();
        tmob.setBounds(175,150,150,25);
        tmob.setFont(new Font("Times New Roman",Font.BOLD,15));
        tmob.setForeground(Color.black);
        add(tmob);

        JLabel address=new JLabel("Address:");
        address.setBounds(65,200,100,30);
        address.setFont(new Font("Times New Roman",Font.BOLD,15));
        address.setForeground(Color.black);
        add(address);

        JTextField taddress=new JTextField();
        taddress.setBounds(175,200,150,25);
        taddress.setFont(new Font("Times New Roman",Font.BOLD,15));
        taddress.setForeground(Color.black);
        add(taddress);

        JLabel date=new JLabel("Date");
        date.setBounds(65,250,100,30);
        date.setFont(new Font("Times New Roman",Font.BOLD,15));
        date.setForeground(Color.black);
        add(date);


        JDateChooser tdob=new JDateChooser();
        tdob.setBounds(175,250,150,25);
        tdob.setFont(new Font("arial",Font.BOLD,20));
        tdob.setBackground(new Color(177,252,197));
        add(tdob);

        JLabel product=new JLabel("Product Name:");
        product.setBounds(65,300,100,30);
        product.setFont(new Font("Times New Roman",Font.BOLD,15));
        product.setForeground(Color.black);
        add(product);

        String[] x = new String[0];
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
            Statement st = con.createStatement();
            Statement sta=con.createStatement();
            ResultSet jk=sta.executeQuery("select p_name from stock");
            ResultSet rs=st.executeQuery("select count(p_name) from stock");

            rs.next();
            int p=Integer.parseInt(rs.getString(1));
            x=new String[p];

            int i=0;
            while (jk.next())
            {
                x[i]=jk.getString("p_name");
                i++;
            }
            }catch(Exception e1)
             {
                e1.printStackTrace();
             }
        JComboBox tproduct =new JComboBox(x);
        tproduct.setBounds(175,300,150,25);
        tproduct.setFont(new Font("arial",Font.BOLD,15));
        tproduct.setBackground(new Color(177,252,197));
        add(tproduct);


        JLabel qty=new JLabel("Quantity");
        qty.setBounds(65,350,100,30);
        qty.setFont(new Font("Times New Roman",Font.BOLD,15));
        qty.setForeground(Color.black);
        add(qty);

        String items1[]={"1","2","3","4","5","6","7","8","9","10"};
        JComboBox tqty =new JComboBox(items1);
        tqty.setBounds(175,350,150,25);
        tqty.setFont(new Font("arial",Font.BOLD,15));
        tqty.setBackground(new Color(177,252,197));
        add(tqty);


           JButton add = new JButton("Add");
            add.setBounds(450, 10, 100, 30);
            add.setBackground(Color.black);
            add.setForeground(Color.white);
            add(add);
            add.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String id = tid.getText();
                    String name = tname.getText();
                    String mob = tmob.getText();
                    String address = taddress.getText();
                    String dob=((JTextField)tdob.getDateEditor().getUiComponent()).getText();
                    String product=(String)tproduct.getSelectedItem();
                    String qty=(String)tqty.getSelectedItem();
                    String total = null;
                    try
                    {
                        Class.forName("org.postgresql.Driver");
                        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                        Statement state = con.createStatement();
                        ResultSet pq=state.executeQuery("select p_price from stock where p_name='"+product+"'");
                        pq.next();
                        total=""+(Integer.parseInt(pq.getString(1))*(Integer.parseInt(qty)));

                    }catch(Exception e3)
                    {e3.printStackTrace();}

                    try
                    {
                        Class.forName("org.postgresql.Driver");
                        Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                        Statement st = con.createStatement();
                        st.executeUpdate("insert into billing values('" + id + "','" + name + "','" + dob + "','" + address + "','" + dob + "','" + product + "','" + qty + "','" + total + "')");
                        JOptionPane.showMessageDialog(null, "Adding Bill Successfully");
                    }catch(Exception e4)
                    {
                       e4.printStackTrace();
                    }

                }
            });

            JButton view = new JButton("View");
            view.setBounds(560, 10, 100, 30);
            view.setBackground(Color.black);
            view.setForeground(Color.white);
            add(view);
            view.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    new View_Billing();
                }
            });


            JButton back = new JButton("Back");
            back.setBounds(670, 10, 100, 30);
            back.setBackground(Color.black);
            back.setForeground(Color.white);
            add(back);
            back.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    setVisible(false);
                    new Main_Class();
                }
            });


            ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/billing.jpg"));
            Image i2 = i1.getImage().getScaledInstance(1000, 600, Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            JLabel img = new JLabel(i3);
            img.setBounds(0, 0, 1000, 600);
            add(img);


            setVisible(true);
            setSize(1000, 600);
            setLocationRelativeTo(null);

    }
        public static void main(String[] args)
        {
           new Billing();
        }
}
