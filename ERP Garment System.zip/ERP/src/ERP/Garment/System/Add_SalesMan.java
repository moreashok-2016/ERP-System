package ERP.Garment.System;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
public class Add_SalesMan extends JFrame
{

    JDateChooser tdob;
    Add_SalesMan()
    {
        setLayout(null);
        Container c=getContentPane();
        c.setBackground(new Color(20,227,179));

        JLabel heading=new JLabel("Add SalesMan Details");
        heading.setBounds(300,50,500,40);
        heading.setFont(new Font("serif",Font.BOLD,30));
        c.add(heading);

        JLabel name=new JLabel("Name:");
        name.setBounds(50,150,150,30);
        name.setFont(new Font("arial",Font.BOLD,20));
        c.add(name);

        JTextField tname=new JTextField();
        tname.setBounds(230,150,150,30);
        tname.setFont(new Font("arial",Font.BOLD,20));
        tname.setBackground(new Color(177,252,197));
        c.add(tname);

        JLabel fname=new JLabel("Father Name:");
        fname.setBounds(450,150,150,30);
        fname.setFont(new Font("arial",Font.BOLD,20));
        c.add(fname);

        JTextField tfname=new JTextField();
        tfname.setBounds(650,150,150,30);
        tfname.setFont(new Font("arial",Font.BOLD,20));
        tfname.setBackground(new Color(177,252,197));
        c.add(tfname);

        JLabel dob=new JLabel("Date Of Birth");
        dob.setBounds(50,200,150,30);
        dob.setFont(new Font("arial",Font.BOLD,20));
        c.add(dob);

        tdob=new JDateChooser();
        tdob.setBounds(230,200,150,30);
        tdob.setFont(new Font("arial",Font.BOLD,20));
        tdob.setBackground(new Color(177,252,197));
        c.add(tdob);

        JLabel address=new JLabel("Address:");
        address.setBounds(450,200,150,30);
        address.setFont(new Font("arial",Font.BOLD,20));
        c.add(address);

        JTextField taddress=new JTextField();
        taddress.setBounds(650,200,150,30);
        taddress.setFont(new Font("arial",Font.BOLD,20));
        taddress.setBackground(new Color(177,252,197));
        c.add(taddress);


        JLabel phone=new JLabel("Phone No:");
        phone.setBounds(50,250,150,30);
        phone.setFont(new Font("arial",Font.BOLD,20));
        c.add(phone);

        JTextField tphone=new JTextField();
        tphone.setBounds(230,250,150,30);
        tphone.setFont(new Font("arial",Font.BOLD,20));
        tphone.setBackground(new Color(177,252,197));
        c.add(tphone);

        JLabel aadhar=new JLabel("Aadhar No:");
        aadhar.setBounds(450,250,150,30);
        aadhar.setFont(new Font("arial",Font.BOLD,20));
        c.add(aadhar);

        JTextField taadhar=new JTextField();
        taadhar.setBounds(650,250,150,30);
        taadhar.setFont(new Font("arial",Font.BOLD,20));
        taadhar.setBackground(new Color(177,252,197));
        c.add(taadhar);


        JLabel email=new JLabel("Emai Id:");
        email.setBounds(50,300,150,30);
        email.setFont(new Font("arial",Font.BOLD,20));
        c.add(email);

        JTextField temail=new JTextField();
        temail.setBounds(230,300,150,30);
        temail.setFont(new Font("arial",Font.BOLD,20));
        temail.setBackground(new Color(177,252,197));
        c.add(temail);

        JLabel salary=new JLabel("Salary:");
        salary.setBounds(450,300,150,30);
        salary.setFont(new Font("arial",Font.BOLD,20));
        c.add(salary);

        JTextField tsalary=new JTextField();
        tsalary.setBounds(650,300,150,30);
        tsalary.setFont(new Font("arial",Font.BOLD,20));
        tsalary.setBackground(new Color(177,252,197));
        c.add(tsalary);

        JLabel sid=new JLabel("Employee ID:");
        sid.setBounds(50,350,150,30);
        sid.setFont(new Font("arial",Font.BOLD,20));
        c.add(sid);

        JTextField tid=new JTextField();
        tid.setBounds(230,350,150,30);
        tid.setFont(new Font("SAN_SARIF",Font.BOLD,20));
        tid.setForeground(Color.RED);
        c.add(tid);


        JButton add=new JButton("ADD");
        add.setBounds(250,500,150,30);
        add.setBackground(Color.BLACK);
        add.setForeground(Color.WHITE);
        c.add(add);
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String name=tname.getText();
                String fname=tfname.getText();
                String dob=((JTextField)tdob.getDateEditor().getUiComponent()).getText();
                String salary=tsalary.getText();
                String address=taddress.getText();
                String aadhar=taadhar.getText();
                String phone=tphone.getText();
                String email=temail.getText();
                String id=tid.getText();

                try {
                    Class.forName("org.postgresql.Driver");
                    Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:1234/erp", "postgres", "ashoka");
                    Statement st = con.createStatement();
                    st.executeUpdate("insert into salesman values('" + name + "','" + fname + "','" + dob + "','" + address + "','" + phone + "','" + aadhar + "','" + email + "','" + salary + "','" + id + "')");

                    JOptionPane.showMessageDialog(null, "Details Saved Successfully");
                    new SalesMan();
                    setVisible(false);

                } catch (Exception e3) {
                    System.out.println("Exception:" + e3);
                }


            }
        });

        JButton back=new JButton("BACK");
        back.setBounds(450,500,150,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        c.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e1)
            {
                setVisible(false);
                new SalesMan();
            }
        });



        setSize(900,700);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String args[])
    {
          new Add_SalesMan();
    }
}
